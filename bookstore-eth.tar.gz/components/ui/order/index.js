

export { default as OrderModal } from "./modal"
