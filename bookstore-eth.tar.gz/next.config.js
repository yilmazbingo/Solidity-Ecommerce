


module.exports = {
  reactStrictMode: true,
  images: {
    domains: [
      "thrangra.sirv.com"
    ]
  }
}
